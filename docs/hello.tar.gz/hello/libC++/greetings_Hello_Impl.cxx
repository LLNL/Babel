// 
// File:          greetings_Hello_Impl.cxx
// Symbol:        greetings.Hello-v1.0
// Symbol Type:   class
// Babel Version: 1.5.0 (Revision: 6840  trunk)
// Description:   Server-side implementation for greetings.Hello
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 
#include "greetings_Hello_Impl.hxx"

// 
// Includes for all method dependencies.
// 
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif
#ifndef included_sidl_NotImplementedException_hxx
#include "sidl_NotImplementedException.hxx"
#endif
// DO-NOT-DELETE splicer.begin(greetings.Hello._includes)
#include<iostream>
// DO-NOT-DELETE splicer.end(greetings.Hello._includes)

// special constructor, used for data wrapping(required).  Do not put code here unless you really know what you're doing!
greetings::Hello_impl::Hello_impl() : StubBase(reinterpret_cast< void*>(
  ::greetings::Hello::_wrapObj(reinterpret_cast< void*>(this))),false) , 
  _wrapped(true){ 
  // DO-NOT-DELETE splicer.begin(greetings.Hello._ctor2)
  // insert code here (ctor2)
  // DO-NOT-DELETE splicer.end(greetings.Hello._ctor2)
}

// user defined constructor
void greetings::Hello_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(greetings.Hello._ctor)
  // insert code here (constructor)
  // DO-NOT-DELETE splicer.end(greetings.Hello._ctor)
}

// user defined destructor
void greetings::Hello_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(greetings.Hello._dtor)
  // insert code here (destructor)
  // DO-NOT-DELETE splicer.end(greetings.Hello._dtor)
}

// static class initializer
void greetings::Hello_impl::_load() {
  // DO-NOT-DELETE splicer.begin(greetings.Hello._load)
  // insert code here (class initialization)
  // DO-NOT-DELETE splicer.end(greetings.Hello._load)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  setName[]
 */
void
greetings::Hello_impl::setName_impl (
  /* in */const ::std::string& name ) 
{
  // DO-NOT-DELETE splicer.begin(greetings.Hello.setName)
  _name = name;
  // DO-NOT-DELETE splicer.end(greetings.Hello.setName)
}

/**
 * Method:  sayHello[]
 */
void
greetings::Hello_impl::sayHello_impl () 

{
  // DO-NOT-DELETE splicer.begin(greetings.Hello.sayHello)
  std::cout << "Hello world from " << _name << std::endl;
  // DO-NOT-DELETE splicer.end(greetings.Hello.sayHello)
}


// DO-NOT-DELETE splicer.begin(greetings.Hello._misc)
// insert code here (miscellaneous code)
// DO-NOT-DELETE splicer.end(greetings.Hello._misc)

