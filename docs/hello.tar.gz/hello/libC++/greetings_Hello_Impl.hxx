// 
// File:          greetings_Hello_Impl.hxx
// Symbol:        greetings.Hello-v1.0
// Symbol Type:   class
// Babel Version: 1.5.0 (Revision: 6840  trunk)
// Description:   Server-side implementation for greetings.Hello
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// 

#ifndef included_greetings_Hello_Impl_hxx
#define included_greetings_Hello_Impl_hxx

#ifndef included_sidl_cxx_hxx
#include "sidl_cxx.hxx"
#endif
#ifndef included_greetings_Hello_IOR_h
#include "greetings_Hello_IOR.h"
#endif
#ifndef included_greetings_Hello_hxx
#include "greetings_Hello.hxx"
#endif
#ifndef included_sidl_BaseClass_hxx
#include "sidl_BaseClass.hxx"
#endif
#ifndef included_sidl_BaseInterface_hxx
#include "sidl_BaseInterface.hxx"
#endif
#ifndef included_sidl_ClassInfo_hxx
#include "sidl_ClassInfo.hxx"
#endif


// DO-NOT-DELETE splicer.begin(greetings.Hello._hincludes)
// insert code here (includes or arbitrary code)
// DO-NOT-DELETE splicer.end(greetings.Hello._hincludes)

namespace greetings { 

  /**
   * Symbol "greetings.Hello" (version 1.0)
   */
  class Hello_impl : public virtual ::greetings::Hello 
  // DO-NOT-DELETE splicer.begin(greetings.Hello._inherits)
  // insert code here (optional inheritance here)
  // DO-NOT-DELETE splicer.end(greetings.Hello._inherits)

  {

  // All data marked protected will be accessable by 
  // descendant Impl classes
  protected:

    bool _wrapped;

    // DO-NOT-DELETE splicer.begin(greetings.Hello._implementation)
    std::string _name;
    // DO-NOT-DELETE splicer.end(greetings.Hello._implementation)

  public:
    // default constructor, used for data wrapping(required)
    Hello_impl();
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Hello_impl( struct greetings_Hello__object * ior ) : StubBase(ior,true) , 
      _wrapped(false) {
      ior->d_data = this;
      _ctor();
    }


    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Hello_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

    // true if this object was created by a user newing the impl
    inline bool _isWrapped() {return _wrapped;}

    // static class initializer
    static void _load();

  public:

    /**
     * user defined non-static method.
     */
    void
    setName_impl (
      /* in */const ::std::string& name
    )
    ;

    /**
     * user defined non-static method.
     */
    void
    sayHello_impl() ;
  };  // end class Hello_impl

} // end namespace greetings

// DO-NOT-DELETE splicer.begin(greetings.Hello._hmisc)
// insert code here (miscellaneous things)
// DO-NOT-DELETE splicer.end(greetings.Hello._hmisc)

#endif
